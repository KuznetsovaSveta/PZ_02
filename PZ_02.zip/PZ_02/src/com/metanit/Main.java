package com.metanit;

public class Main {

    public static void main(String[] args) {

        char symb01 = 1067;
        char symb02 ='Ы';

        System.out.println("symb01 contains "+ symb01);
        System.out.println("symb02 contains "+ symb02);

        char cch = 'J';
        int intCch = (int) cch;

        System.out.println("\nJ corresponds with "+ intCch);


        String s1 = "\nI have ";
        String s2 = " apples ";
        int num = 3;
        String s = s1 + num + s2;

        System.out.println(s);


        System.out.println("\nint, double, long, float to String");
        //int to String
        int i = 35;
        String str_i = Integer.toString(i);
        System.out.println(str_i);

        //double to String
        double  a = 32.4e10;
        String str_a = Double.toString(a);
        System.out.println(str_a);

        //long to String
        long  b = 3422222;
        String str_b = Long.toString(b);
        System.out.println(str_b);

        //float to String
        float  c = 3.46f;
        String str_c = Float.toString(c);
        System.out.println(str_c);

        System.out.println("\nchar to String");
        //char to String
        char ch = 'S';
        // c использованием класса Character
        String charToString = Character.toString(ch);
        System.out.println(charToString);

        // с использованием операции добавления класса String
        String str = "" + ch;
        System.out.println(str);

        //с использованием массива
        String fromChar = new String(new char[] { ch });
        System.out.println(fromChar);

        // с использованием метода valueOf класса String
        String valueOfchar = String.valueOf(ch);
        System.out.println(valueOfchar);


        System.out.println("\nchar to int");
        char sh = '9';
        // c использованием метода getNumericValue
        // класса Character
        int i1 = Character.getNumericValue(sh);
        System.out.println(i1);

        // c использованием метода digit класса Character
        int i2 = Character.digit(sh,10);
        System.out.println(i2);

        System.out.println("\nint to long, float");
        //int to long
        int m = 2015;
        long lm = (long) (m);
        System.out.println(lm);

        //int to float
        int n = 2015;
        float fn = (float) (n);
        System.out.println(fn);

        System.out.println("\nlong to int");
        //long to int
        long ll = 214748364;
        int il = (int) ll;
        System.out.println(il);

        System.out.println("\ndouble to int");
        //double to int
        double d = 3.14;
        int z = (int) d;
        System.out.println(z);



    }

    }

